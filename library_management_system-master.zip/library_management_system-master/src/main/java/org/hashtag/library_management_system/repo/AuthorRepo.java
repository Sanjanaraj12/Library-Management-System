package org.hashtag.library_management_system.repo;

import org.hashtag.library_management_system.entity.Author;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthorRepo extends JpaRepository<Author, Integer>{

}
